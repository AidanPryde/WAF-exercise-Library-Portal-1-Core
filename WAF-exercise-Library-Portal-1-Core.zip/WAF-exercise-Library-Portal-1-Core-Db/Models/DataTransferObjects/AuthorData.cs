﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAF_exercise_Library_Portal_1_Core_Db.Models.DataTransferObjects
{
    public class AuthorData
    {
    }
}
